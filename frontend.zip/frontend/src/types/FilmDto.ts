export type FilmDto = {
  id: number;
  name: string;
  description?: string;
  releaseDate?: string;
  posterUrl?: string;
  genres: { id: number; name: string }[];
  rating?: number;
};

export type CreateFilmDto = {
  name: string;
  description?: string;
  releaseDate?: string;
  genreIds: number[];
};
