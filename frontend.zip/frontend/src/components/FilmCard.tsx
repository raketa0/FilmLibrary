import type { FilmDto } from "../types/FilmDto";

type Props = { film: FilmDto };

export default function FilmCard({ film }: Props) {
  return (
    <div className="card">
      <img src={film.posterUrl || '/placeholder.png'} alt={film.name} style={{ width: '100%', borderRadius: '12px' }} />
      <h2>{film.name}</h2>
      <p>{film.genres.map(g => g.name).join(', ')}</p>
      <p>Рейтинг: {film.rating ?? '-'}</p>
    </div>
  );
}
