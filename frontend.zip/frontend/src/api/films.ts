import { client } from './client';
import type { CreateFilmDto, FilmDto } from '../types/FilmDto';

const API = '/films';

export async function getAllFilms(): Promise<FilmDto[]> {
  const { data } = await client.get<FilmDto[]>(API);
  return data;
}

export async function createFilm(dto: CreateFilmDto): Promise<FilmDto> {
  const { data } = await client.post<FilmDto>(API, dto);
  return data;
}

export async function getAllGenres(): Promise<{ id: number; name: string }[]> {
  const { data } = await client.get('/genres');
  return data;
}
