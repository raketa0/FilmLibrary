import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { createFilm, getAllGenres } from '../api/films';
import type { CreateFilmDto } from '../types/FilmDto';

type FormValues = {
  name: string;
  description: string;
  releaseDate: string;
  genreIds: number[];
};

export default function CreateFilmPage() {
  const [genres, setGenres] = useState<{ id: number; name: string }[]>([]);
  const { register, handleSubmit, formState, setValue } = useForm<FormValues>({
    defaultValues: {
      name: '',
      description: '',
      releaseDate: '',
      genreIds: [],
    },
  });

  useEffect(() => {
    getAllGenres().then(setGenres);
  }, []);

  const onSubmit = async (data: FormValues) => {
    try {
      const dto: CreateFilmDto = {
        name: data.name,
        description: data.description,
        releaseDate: data.releaseDate,
        genreIds: data.genreIds,
      };
      await createFilm(dto);
      alert('Фильм успешно создан!');
    } catch (e) {
      alert('Ошибка создания фильма');
    }
  };

  const handleGenreChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selected = Array.from(e.target.selectedOptions).map(o => Number(o.value));
    setValue('genreIds', selected);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="form-container">
      <h1 className="form-title">Создать фильм</h1>

      <div className="form-group">
        <label>Название</label>
        <input {...register('name', { required: 'Название обязательно' })} />
      </div>

      <div className="form-group">
        <label>Описание</label>
        <textarea {...register('description')} rows={4}></textarea>
      </div>

      <div className="form-group">
        <label>Дата выхода</label>
        <input type="date" {...register('releaseDate', { required: 'Укажите дату выхода' })} />
      </div>

      <div className="form-group">
        <label>Жанры</label>
        <select multiple {...register('genreIds')} onChange={handleGenreChange}>
          {genres.map(g => (
            <option key={g.id} value={g.id}>
              {g.name}
            </option>
          ))}
        </select>
      </div>

      <button type="submit" disabled={formState.isSubmitting}>Создать фильм</button>

      <style>{`
        .form-container {
          max-width: 500px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          gap: 16px;
          padding: 20px;
          border: 1px solid #ccc;
          border-radius: 8px;
          background-color: #f8f8f8;
        }
        .form-title {
          text-align: center;
          font-size: 1.5rem;
          margin-bottom: 10px;
        }
        .form-group {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .form-group input,
        .form-group textarea,
        .form-group select {
          padding: 8px;
          border: 1px solid #ccc;
          border-radius: 4px;
          font-size: 1rem;
        }
        button {
          padding: 10px;
          border: none;
          border-radius: 4px;
          background-color: #007bff;
          color: white;
          font-size: 1rem;
          cursor: pointer;
        }
        button:disabled {
          background-color: #ccc;
          cursor: not-allowed;
        }
      `}</style>
    </form>
  );
}
