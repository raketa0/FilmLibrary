import { useEffect, useState } from "react";
import { getAllFilms } from "../api/films";
import type { FilmDto } from "../types/FilmDto";
import FilmCard from "../components/FilmCard";

export default function FilmsPage() {
  const [films, setFilms] = useState<FilmDto[]>([]);

  useEffect(() => {
    getAllFilms().then(setFilms);
  }, []);

  return (
    <div className="container">
      <h1>Фильмы</h1>
      <div className="grid grid-cols-3">
        {films.map(film => <FilmCard key={film.id} film={film} />)}
      </div>
    </div>
  );
}
